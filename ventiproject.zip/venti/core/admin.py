from django.contrib import admin

# Register your models here.

from .models import *




admin.site.register(Machine)
admin.site.register(time_model)
admin.site.register(Mlmodel)
admin.site.register(Fault_occur)


admin.site.register(Fault_future)
admin.site.register(Email_user)
admin.site.register(permission)
admin.site.register(newuser)


admin.site.register(level1)
admin.site.register(level2)
admin.site.register(level3)
admin.site.register(level4)